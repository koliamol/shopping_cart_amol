<?php
$this->title = 'Dashboard Page';
$this->params['breadcrumbs'] = [['label' => $this->title]];
?>

<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?= date('Y') ?> <a href="#">Fyntune</a>.</strong> All rights reserved.
</footer>